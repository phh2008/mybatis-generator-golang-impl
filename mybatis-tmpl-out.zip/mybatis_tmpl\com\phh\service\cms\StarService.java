package com.phh.service.cms;

import org.springframework.stereotype.Service;

import com.phh.do.cms.StarDO;
import com.phh.dao.cms.StarDAO;
import com.phh.service.BaseServiceImpl;

/**
 * 点赞表
 *
 * @author 彭会会
 * @date 2019-08-12
 */
@Service
public class StarService extends BaseServiceImpl {

}