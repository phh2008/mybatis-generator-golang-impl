package com.phh.service.mem;

import org.springframework.stereotype.Service;

import com.phh.do.mem.UserDO;
import com.phh.dao.mem.UserDAO;
import com.phh.service.BaseServiceImpl;

/**
 * 用户表
 *
 * @author 彭会会
 * @date 2019-08-12
 */
@Service
public class UserService extends BaseServiceImpl {

}