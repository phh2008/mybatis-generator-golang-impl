package com.phh.service.cms;

import org.springframework.stereotype.Service;

import com.phh.do.cms.CommentDO;
import com.phh.dao.cms.CommentDAO;
import com.phh.service.BaseServiceImpl;

/**
 * 评论
 *
 * @author 彭会会
 * @date 2019-08-12
 */
@Service
public class CommentService extends BaseServiceImpl {

}