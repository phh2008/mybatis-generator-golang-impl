package com.phh.dao.mem;

import com.phh.do.mem.UserDO;
import com.phh.dao.BaseDAO;

/**
 * 用户表
 *
 * @author 彭会会
 * @date 2019-08-12
 */
public interface UserDAO extends BaseDAO<UserDO> {

}