package com.phh.dao.cms;

import com.phh.do.cms.StarDO;
import com.phh.dao.BaseDAO;

/**
 * 点赞表
 *
 * @author 彭会会
 * @date 2019-08-12
 */
public interface StarDAO extends BaseDAO<StarDO> {

}